package martian.riddles.model;

public class Riddle {

    private String riddle;

    public String getRiddle() {
        return riddle;
    }

    public void setRiddle(String riddle) {
        this.riddle = riddle;
    }
}
