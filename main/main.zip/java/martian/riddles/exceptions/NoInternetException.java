package martian.riddles.exceptions;

public class NoInternetException extends Exception {
}
