package martian.riddles.exceptions;

public class ErrorOnServerException extends Exception {
}
